def equation(x: int, y: int) -> int:
    z = 2 * x + 3 * y
    return z


def equation2(x: int, y: int) -> int:
    z = x / y
    return z
